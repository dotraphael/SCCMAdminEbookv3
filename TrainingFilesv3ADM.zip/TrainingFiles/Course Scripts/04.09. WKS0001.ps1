Set-ExecutionPolicy Unrestricted -Force

\\srv0001\trainingfiles\scripts\WKS0001.ps1