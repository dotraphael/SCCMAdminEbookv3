Start-CMContentDistribution -ApplicationName "Google Chrome" -DistributionPointGroupName "Training Lab"
