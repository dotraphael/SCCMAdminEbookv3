$SiteCode = "001"

Set-CMCollectionMembershipEvaluationComponent -SiteCode $SiteCode -EvaluationMins 3