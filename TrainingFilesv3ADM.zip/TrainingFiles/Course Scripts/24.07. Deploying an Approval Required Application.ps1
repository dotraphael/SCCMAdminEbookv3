New-CMApplicationDeployment -CollectionName "Users OU" -Name "Java8" -ApprovalRequired $true
