Start-Process -Filepath ("c:\windows\ccm\ccmeval.exe") -wait
