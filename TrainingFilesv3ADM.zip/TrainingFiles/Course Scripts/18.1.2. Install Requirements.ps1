Get-WindowsFeature -Name Web-Server | Install-WindowsFeature 
Get-WindowsFeature -Name Web-Metabase | Install-WindowsFeature 
Get-WindowsFeature -Name Web-ASP-Net | Install-WindowsFeature 
Get-WindowsFeature -Name NET-WCF-HTTP-Activation45 | Install-WindowsFeature 
Get-WindowsFeature -Name NET-HTTP-Activation | Install-WindowsFeature 
Get-WindowsFeature -Name NET-Non-HTTP-Activ | Install-WindowsFeature 
