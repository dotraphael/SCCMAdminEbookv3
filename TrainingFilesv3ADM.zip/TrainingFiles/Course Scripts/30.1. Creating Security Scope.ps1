$SecurityScope = "Application Administrator for Windows 10 Machines"
New-CMSecurityScope -Name "$SecurityScope"