Get-WindowsFeature -Name Web-Server | Install-WindowsFeature 
Get-WindowsFeature -Name Web-Metabase | Install-WindowsFeature 
