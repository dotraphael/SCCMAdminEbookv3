#steps 1 to 09
$AppName = "7-Zip 16"
Start-CMContentDistribution -ApplicationName "$AppName" -DistributionPointName clouddp.classroom.intranet