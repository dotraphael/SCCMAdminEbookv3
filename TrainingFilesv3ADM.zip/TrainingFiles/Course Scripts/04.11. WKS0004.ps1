Set-ExecutionPolicy Unrestricted -Force

\\srv0001\trainingfiles\scripts\WKS0004.ps1