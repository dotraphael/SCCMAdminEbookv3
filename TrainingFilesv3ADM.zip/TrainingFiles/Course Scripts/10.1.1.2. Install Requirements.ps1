Get-WindowsFeature -Name RDC | Install-WindowsFeature 
Get-WindowsFeature -Name Web-Server | Install-WindowsFeature 
Get-WindowsFeature -Name Web-ISAPI-Ext | Install-WindowsFeature 
Get-WindowsFeature -Name Web-Metabase | Install-WindowsFeature 
Get-WindowsFeature -Name Web-Windows-Auth | Install-WindowsFeature 
