Start-Process -Filepath ("\\srv0001\Trainingfiles\Source\SQLMgmt\SSMS-Setup-ENU.exe") -ArgumentList ('/install /quiet /norestart') -wait
