Enable-Appv
start-sleep 5
Start-Process -Filepath ("shutdown") -ArgumentList ("/r /t 0")
