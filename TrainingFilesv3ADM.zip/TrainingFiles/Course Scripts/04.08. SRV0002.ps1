Cd \TrainingFiles\Scripts
.\SRV0002.ps1