New-CMBoundary -DisplayName "Training Lab Boundary" -BoundaryType IPRange -Value "192.168.3.1-192.168.3.254"
