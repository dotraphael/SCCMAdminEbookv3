$AppName = "7-Zip 16"
New-CMApplicationDeployment -CollectionName "Windows 10 Workstations" -Name "$AppName"